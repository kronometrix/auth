lua-resty-gettext
=================

LuaJIT FFI-based gettext library for OpenResty.
